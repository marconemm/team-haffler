//Declaring elements from HTML:
const showResult = document.getElementById("show");
const btnSave = document.getElementById("btnSave");
const inputMemberName = document.getElementById("memberName");

//Declaring variables:
const membersList = [];

btnSave.addEventListener("click", e => {
    e.preventDefault();
    const newMember = {name: inputMemberName.value};
    
    membersList.push(newMember);
    
    console.log(newMember.name);
});
